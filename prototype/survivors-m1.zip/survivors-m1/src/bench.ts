// ヘッドレス実行のシミュレーション性能計測: npm run bench
// 描画を含まないので、ここで出る値は「ロジック側の処理時間」のみ。
import { World } from './sim/world';
import { TICK } from './sim/config';

function run(label: string, enemyTarget: number, fireMul: number, seconds = 60) {
  const w = new World(12345);
  w.setEnemyTarget(enemyTarget);
  w.fireRateMul = fireMul;
  for (let i = 0; i < 600; i++) w.step(TICK); // ウォームアップ(10秒)
  const ticks = Math.round(seconds / TICK);
  const times = new Float64Array(ticks);
  let sumB = 0, sumC = 0, maxB = 0, sumE = 0;
  const k0 = w.kills;
  for (let i = 0; i < ticks; i++) {
    const t0 = performance.now();
    w.step(TICK);
    times[i] = performance.now() - t0;
    sumB += w.bulletCount; sumC += w.coinCount; sumE += w.enemyCount;
    if (w.bulletCount > maxB) maxB = w.bulletCount;
  }
  const sorted = Array.from(times).sort((a, b) => a - b);
  const avg = sorted.reduce((a, b) => a + b, 0) / ticks;
  const p99 = sorted[Math.floor(ticks * 0.99)];
  const max = sorted[ticks - 1];
  console.log(
    `${label.padEnd(26)} 平均 ${avg.toFixed(3)}ms  p99 ${p99.toFixed(3)}ms  最大 ${max.toFixed(3)}ms | ` +
    `敵 ${(sumE / ticks).toFixed(0)}  弾 平均${(sumB / ticks).toFixed(0)}/最大${maxB}  通貨 ${(sumC / ticks).toFixed(0)}  撃破/秒 ${((w.kills - k0) / seconds).toFixed(1)}`
  );
}

console.log('1ティック(1/60秒)あたりのシミュレーション処理時間 [60秒分、ウォームアップ除く]');
console.log('※ 16.7ms が60fpsの1フレーム予算。描画時間は含まない。\n');
run('敵600 / 発射速度×1', 600, 1);
run('敵600 / 発射速度×8', 600, 8);
run('敵1000 / 発射速度×1', 1000, 1);
run('敵1000 / 発射速度×8', 1000, 8);
run('敵300 / 発射速度×1', 300, 1);
run('敵600 / 発射速度×32', 600, 32);
run('敵1000 / 発射速度×32', 1000, 32);
