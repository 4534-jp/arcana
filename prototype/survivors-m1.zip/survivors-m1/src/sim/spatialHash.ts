/**
 * 一様グリッドによる空間ハッシュ。
 * 毎ティック clear() → insert() で作り直し、query() で円と重なりうる要素を取り出す。
 * 厳密な距離判定は呼び出し側で行う。
 */
export class SpatialHash {
  readonly cols: number;
  readonly rows: number;
  private readonly head: Int32Array;
  private readonly next: Int32Array;

  constructor(width: number, height: number, private readonly cell: number, maxItems: number) {
    this.cols = Math.ceil(width / cell);
    this.rows = Math.ceil(height / cell);
    this.head = new Int32Array(this.cols * this.rows).fill(-1);
    this.next = new Int32Array(maxItems);
  }

  clear(): void {
    this.head.fill(-1);
  }

  private cx(x: number): number {
    const c = (x / this.cell) | 0;
    return c < 0 ? 0 : c >= this.cols ? this.cols - 1 : c;
  }

  private cy(y: number): number {
    const c = (y / this.cell) | 0;
    return c < 0 ? 0 : c >= this.rows ? this.rows - 1 : c;
  }

  insert(i: number, x: number, y: number): void {
    const c = this.cy(y) * this.cols + this.cx(x);
    this.next[i] = this.head[c];
    this.head[c] = i;
  }

  /** 円(x,y,r)と重なりうるセルの要素番号を out に書き込み、個数を返す。 */
  query(x: number, y: number, r: number, out: Int32Array): number {
    const x0 = this.cx(x - r);
    const x1 = this.cx(x + r);
    const y0 = this.cy(y - r);
    const y1 = this.cy(y + r);
    let n = 0;
    for (let cy = y0; cy <= y1; cy++) {
      const row = cy * this.cols;
      for (let cx = x0; cx <= x1; cx++) {
        for (let i = this.head[row + cx]; i !== -1; i = this.next[i]) {
          if (n < out.length) out[n++] = i;
        }
      }
    }
    return n;
  }
}
