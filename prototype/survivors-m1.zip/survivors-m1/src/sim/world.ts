import {
  BULLET, CELL, COIN, ENEMY, MAP_H, MAP_W, MAX_BULLETS, MAX_COINS, MAX_ENEMIES,
  PLAYER, SPAWN, TOWER, TOWER_COUNT,
} from './config';
import { SpatialHash } from './spatialHash';

/** 再現性のある乱数(seed固定)。 */
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** 空き番号を管理するプール(確保・解放が O(1))。 */
class IndexPool {
  private readonly stack: Int32Array;
  private top: number;
  constructor(readonly size: number) {
    this.stack = new Int32Array(size);
    this.top = size;
    for (let i = 0; i < size; i++) this.stack[i] = size - 1 - i;
  }
  alloc(): number {
    return this.top > 0 ? this.stack[--this.top] : -1;
  }
  free(i: number): void {
    this.stack[this.top++] = i;
  }
  get used(): number {
    return this.size - this.top;
  }
}

/** 描画に依存しない純粋なシミュレーション。Phaserは一切importしない。 */
export class World {
  // 敵
  readonly ex = new Float32Array(MAX_ENEMIES);
  readonly ey = new Float32Array(MAX_ENEMIES);
  readonly ehp = new Float32Array(MAX_ENEMIES);
  readonly ealive = new Uint8Array(MAX_ENEMIES);
  // タワー
  readonly tx = new Float32Array(TOWER_COUNT);
  readonly ty = new Float32Array(TOWER_COUNT);
  private readonly tcool = new Float32Array(TOWER_COUNT);
  // 弾
  readonly bx = new Float32Array(MAX_BULLETS);
  readonly by = new Float32Array(MAX_BULLETS);
  private readonly bvx = new Float32Array(MAX_BULLETS);
  private readonly bvy = new Float32Array(MAX_BULLETS);
  private readonly blife = new Float32Array(MAX_BULLETS);
  private readonly bdmg = new Float32Array(MAX_BULLETS);
  readonly balive = new Uint8Array(MAX_BULLETS);
  // 通貨(近くの通貨は統合して1つにまとめる)
  readonly cx = new Float32Array(MAX_COINS);
  readonly cy = new Float32Array(MAX_COINS);
  readonly cval = new Float32Array(MAX_COINS);
  readonly calive = new Uint8Array(MAX_COINS);
  // プレイヤー
  px = MAP_W / 2;
  py = MAP_H / 2;
  private pcool = 0;
  private pAngle = 0;

  // 設定(検証中に変更できる)
  enemyTarget = 600;
  fireRateMul = 1;

  // 統計
  time = 0;
  kills = 0;
  contactHits = 0;
  gold = 0;
  mergedDrops = 0;

  private readonly enemyPool = new IndexPool(MAX_ENEMIES);
  private readonly bulletPool = new IndexPool(MAX_BULLETS);
  private readonly coinPool = new IndexPool(MAX_COINS);
  private readonly hash = new SpatialHash(MAP_W, MAP_H, CELL, MAX_ENEMIES);
  private readonly buf = new Int32Array(MAX_ENEMIES);
  private readonly rng: () => number;

  constructor(seed = 1) {
    this.rng = mulberry32(seed);
    // タワーは画面中央に格子状に配置(最小間隔 spacing)
    const rows = Math.ceil(TOWER_COUNT / TOWER.cols);
    for (let i = 0; i < TOWER_COUNT; i++) {
      const col = i % TOWER.cols;
      const row = Math.floor(i / TOWER.cols);
      this.tx[i] = MAP_W / 2 + (col - (TOWER.cols - 1) / 2) * TOWER.spacing;
      this.ty[i] = MAP_H / 2 + (row - (rows - 1) / 2) * TOWER.spacing;
      this.tcool[i] = this.rng() * TOWER.interval;
    }
  }

  get enemyCount(): number { return this.enemyPool.used; }
  get bulletCount(): number { return this.bulletPool.used; }
  get coinCount(): number { return this.coinPool.used; }

  setEnemyTarget(n: number): void {
    this.enemyTarget = Math.max(0, Math.min(MAX_ENEMIES, n));
  }

  step(dt: number): void {
    this.time += dt;
    this.updatePlayer(dt);
    this.spawnEnemies();
    this.rebuildHash();
    this.updateEnemies(dt);
    this.updateTowers(dt);
    this.updateBullets(dt);
    this.updateCoins();
  }

  // ---- プレイヤー ----
  private updatePlayer(dt: number): void {
    // 円軌道を一定速度で周回(タワー群の中を動き回る想定)
    this.pAngle += (PLAYER.speed / PLAYER.orbitRadius) * dt;
    this.px = MAP_W / 2 + Math.cos(this.pAngle) * PLAYER.orbitRadius;
    this.py = MAP_H / 2 + Math.sin(this.pAngle) * PLAYER.orbitRadius;
    this.pcool -= dt;
    if (this.pcool <= 0) {
      const e = this.nearestEnemy(this.px, this.py, PLAYER.range);
      if (e >= 0) {
        this.fire(this.px, this.py, this.ex[e], this.ey[e], PLAYER.damage);
        this.pcool = PLAYER.interval / this.fireRateMul;
      } else {
        this.pcool = 0;
      }
    }
  }

  // ---- 敵の出現(除外距離ルールつき。予告マーカーはM1では省略) ----
  private spawnEnemies(): void {
    let budget = SPAWN.perTick;
    while (budget-- > 0 && this.enemyPool.used < this.enemyTarget) {
      const i = this.enemyPool.alloc();
      if (i < 0) break;
      this.placeSpawn(i);
      this.ehp[i] = ENEMY.hp;
      this.ealive[i] = 1;
    }
  }

  private placeSpawn(i: number): void {
    for (let a = 0; a < SPAWN.attempts; a++) {
      const x = this.rng() * MAP_W;
      const y = this.rng() * MAP_H;
      if (this.isValidSpawn(x, y)) {
        this.ex[i] = x;
        this.ey[i] = y;
        return;
      }
    }
    // 有効地点が見つからない場合はマップ端(本番では強制スポーン領域に置き換える)
    const t = this.rng() * 2 * (MAP_W + MAP_H);
    if (t < MAP_W) { this.ex[i] = t; this.ey[i] = 0; }
    else if (t < MAP_W + MAP_H) { this.ex[i] = MAP_W; this.ey[i] = t - MAP_W; }
    else if (t < 2 * MAP_W + MAP_H) { this.ex[i] = t - MAP_W - MAP_H; this.ey[i] = MAP_H; }
    else { this.ex[i] = 0; this.ey[i] = t - 2 * MAP_W - MAP_H; }
  }

  private isValidSpawn(x: number, y: number): boolean {
    let dx = x - this.px;
    let dy = y - this.py;
    if (dx * dx + dy * dy < SPAWN.playerExclusion * SPAWN.playerExclusion) return false;
    const r2 = SPAWN.towerExclusion * SPAWN.towerExclusion;
    for (let t = 0; t < TOWER_COUNT; t++) {
      dx = x - this.tx[t];
      dy = y - this.ty[t];
      if (dx * dx + dy * dy < r2) return false;
    }
    return true;
  }

  private rebuildHash(): void {
    this.hash.clear();
    for (let i = 0; i < MAX_ENEMIES; i++) {
      if (this.ealive[i]) this.hash.insert(i, this.ex[i], this.ey[i]);
    }
  }

  // ---- 敵の移動(最寄りのタワーかプレイヤーへ向かう) ----
  private updateEnemies(dt: number): void {
    const step = ENEMY.speed * dt;
    const contact2 = ENEMY.contactRange * ENEMY.contactRange;
    for (let i = 0; i < MAX_ENEMIES; i++) {
      if (!this.ealive[i]) continue;
      const x = this.ex[i];
      const y = this.ey[i];
      // 最寄りの標的(プレイヤー+タワー全部の総当たり。タワーは最大20なので十分軽い)
      let bx = this.px;
      let by = this.py;
      let bd = (x - bx) * (x - bx) + (y - by) * (y - by);
      for (let t = 0; t < TOWER_COUNT; t++) {
        const dx = x - this.tx[t];
        const dy = y - this.ty[t];
        const d = dx * dx + dy * dy;
        if (d < bd) { bd = d; bx = this.tx[t]; by = this.ty[t]; }
      }
      if (bd <= contact2) {
        // M1では、標的に到達した敵は消えて補充される(敵数を一定に保つため)
        this.contactHits++;
        this.removeEnemy(i);
        continue;
      }
      const inv = step / Math.sqrt(bd);
      this.ex[i] = x + (bx - x) * inv;
      this.ey[i] = y + (by - y) * inv;
    }
  }

  private removeEnemy(i: number): void {
    this.ealive[i] = 0;
    this.enemyPool.free(i);
  }

  // ---- タワー ----
  private updateTowers(dt: number): void {
    for (let t = 0; t < TOWER_COUNT; t++) {
      this.tcool[t] -= dt;
      if (this.tcool[t] > 0) continue;
      const e = this.nearestEnemy(this.tx[t], this.ty[t], TOWER.range);
      if (e >= 0) {
        this.fire(this.tx[t], this.ty[t], this.ex[e], this.ey[e], TOWER.damage);
        this.tcool[t] = TOWER.interval / this.fireRateMul;
      } else {
        this.tcool[t] = 0;
      }
    }
  }

  private nearestEnemy(x: number, y: number, range: number): number {
    const n = this.hash.query(x, y, range, this.buf);
    const r2 = range * range;
    let best = -1;
    let bd = r2;
    for (let k = 0; k < n; k++) {
      const e = this.buf[k];
      if (!this.ealive[e]) continue;
      const dx = this.ex[e] - x;
      const dy = this.ey[e] - y;
      const d = dx * dx + dy * dy;
      if (d <= bd) { bd = d; best = e; }
    }
    return best;
  }

  // ---- 弾 ----
  private fire(x: number, y: number, tx: number, ty: number, dmg: number): void {
    const b = this.bulletPool.alloc();
    if (b < 0) return; // 上限超過分は発射を見送る
    const dx = tx - x;
    const dy = ty - y;
    const len = Math.sqrt(dx * dx + dy * dy) || 1;
    this.bx[b] = x;
    this.by[b] = y;
    this.bvx[b] = (dx / len) * BULLET.speed;
    this.bvy[b] = (dy / len) * BULLET.speed;
    this.blife[b] = BULLET.life;
    this.bdmg[b] = dmg;
    this.balive[b] = 1;
  }

  private updateBullets(dt: number): void {
    const hitR = BULLET.radius + ENEMY.radius;
    const hitR2 = hitR * hitR;
    for (let b = 0; b < MAX_BULLETS; b++) {
      if (!this.balive[b]) continue;
      const x = (this.bx[b] += this.bvx[b] * dt);
      const y = (this.by[b] += this.bvy[b] * dt);
      this.blife[b] -= dt;
      if (this.blife[b] <= 0 || x < 0 || y < 0 || x > MAP_W || y > MAP_H) {
        this.removeBullet(b);
        continue;
      }
      const n = this.hash.query(x, y, hitR, this.buf);
      for (let k = 0; k < n; k++) {
        const e = this.buf[k];
        if (!this.ealive[e]) continue;
        const dx = this.ex[e] - x;
        const dy = this.ey[e] - y;
        if (dx * dx + dy * dy > hitR2) continue;
        this.ehp[e] -= this.bdmg[b];
        if (this.ehp[e] <= 0) this.killEnemy(e);
        this.removeBullet(b);
        break;
      }
    }
  }

  private removeBullet(b: number): void {
    this.balive[b] = 0;
    this.bulletPool.free(b);
  }

  private killEnemy(e: number): void {
    this.kills++;
    this.dropCoin(this.ex[e], this.ey[e], ENEMY.reward);
    this.removeEnemy(e);
  }

  // ---- 通貨(近くに既存の通貨があれば値を加算して新規ドロップしない) ----
  private dropCoin(x: number, y: number, value: number): void {
    const m2 = COIN.mergeRadius * COIN.mergeRadius;
    let near = -1;
    let nd = Infinity;
    for (let c = 0; c < MAX_COINS; c++) {
      if (!this.calive[c]) continue;
      const dx = this.cx[c] - x;
      const dy = this.cy[c] - y;
      const d = dx * dx + dy * dy;
      if (d < nd) { nd = d; near = c; }
    }
    if (near >= 0 && nd <= m2) {
      this.cval[near] += value;
      this.mergedDrops++;
      return;
    }
    const c = this.coinPool.alloc();
    if (c < 0) {
      // 上限に達していたら、距離に関係なく最寄りの通貨へ統合
      if (near >= 0) { this.cval[near] += value; this.mergedDrops++; }
      return;
    }
    this.cx[c] = x;
    this.cy[c] = y;
    this.cval[c] = value;
    this.calive[c] = 1;
  }

  private updateCoins(): void {
    const r2 = PLAYER.pickupRadius * PLAYER.pickupRadius;
    for (let c = 0; c < MAX_COINS; c++) {
      if (!this.calive[c]) continue;
      const dx = this.cx[c] - this.px;
      const dy = this.cy[c] - this.py;
      if (dx * dx + dy * dy <= r2) {
        this.gold += this.cval[c];
        this.calive[c] = 0;
        this.coinPool.free(c);
      }
    }
  }
}
