// ゲームロジックの定数(仮の数値)。ここだけ変えれば検証条件を変えられる。
export const MAP_W = 3840;
export const MAP_H = 2160;
export const TICK = 1 / 60; // 固定タイムステップ(秒)
export const CELL = 64; // 空間ハッシュのセルサイズ(px)

// 配列の確保サイズ(同時存在数の理論上の上限)
export const MAX_ENEMIES = 1000;
export const MAX_BULLETS = 300; // 超過分は発射を見送る
export const MAX_COINS = 300; // 超過分は最寄りの通貨に統合する

export const TOWER_COUNT = 20;

export const ENEMY = { speed: 150, hp: 6, radius: 12, reward: 1, contactRange: 20 };
export const TOWER = { damage: 10, interval: 1.5, range: 600, cols: 5, spacing: 120 };
export const PLAYER = { damage: 5, interval: 0.8, range: 500, orbitRadius: 250, speed: 300, pickupRadius: 80 };
export const BULLET = { speed: 900, radius: 5, life: 0.9 };
export const COIN = { mergeRadius: 100 };

// 出現ルール(出現予告マーカーはM1では省略)
export const SPAWN = {
  perTick: 20, // 1ティックに補充する最大数
  attempts: 8, // ランダム抽選の試行回数
  playerExclusion: 400, // プレイヤーからの除外距離
  towerExclusion: 200, // タワーからの除外距離
};
