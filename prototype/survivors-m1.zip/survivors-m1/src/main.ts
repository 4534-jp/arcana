import Phaser from 'phaser';
import { StressScene } from './render/StressScene';

new Phaser.Game({
  type: Phaser.WEBGL,
  parent: 'app',
  backgroundColor: '#000000',
  scale: {
    mode: Phaser.Scale.RESIZE,
    width: window.innerWidth,
    height: window.innerHeight,
  },
  render: { antialias: false, powerPreference: 'high-performance' },
  scene: [StressScene],
});
