import Phaser from 'phaser';
import { World } from '../sim/world';
import { MAP_H, MAP_W, MAX_BULLETS, MAX_COINS, MAX_ENEMIES, TICK, TOWER_COUNT } from '../sim/config';

/**
 * M1: 負荷検証用のシーン。シミュレーション(World)の結果を表示するだけで、ゲームルールは持たない。
 * 操作: ↑↓ 敵の目標数 ±100 / ←→ 発射速度 ×½・×2 / R 描画のON・OFF(ロジックだけの負荷を見る)
 */
export class StressScene extends Phaser.Scene {
  private world!: World;
  private acc = 0;
  private enemySprites: Phaser.GameObjects.Image[] = [];
  private bulletSprites: Phaser.GameObjects.Image[] = [];
  private coinSprites: Phaser.GameObjects.Image[] = [];
  private playerSprite!: Phaser.GameObjects.Image;
  private hud!: HTMLElement;
  private renderOn = true;
  private hudTimer = 0;
  // 直近1秒の計測値
  private simSum = 0;
  private simMax = 0;
  private syncSum = 0;
  private frames = 0;

  constructor() {
    super('stress');
  }

  create(): void {
    this.makeTextures();
    this.world = new World(12345);

    this.add.rectangle(MAP_W / 2, MAP_H / 2, MAP_W, MAP_H, 0x14161c);
    // 描画順:通貨 → タワー → 敵 → 弾 → プレイヤー
    this.coinSprites = this.makePool(MAX_COINS, 'coin');
    for (let t = 0; t < TOWER_COUNT; t++) this.add.image(this.world.tx[t], this.world.ty[t], 'tower');
    this.enemySprites = this.makePool(MAX_ENEMIES, 'enemy');
    this.bulletSprites = this.makePool(MAX_BULLETS, 'bullet');
    this.playerSprite = this.add.image(this.world.px, this.world.py, 'player');

    this.fitCamera();
    this.scale.on('resize', () => this.fitCamera());

    this.hud = document.getElementById('hud') as HTMLElement;
    const kb = this.input.keyboard;
    if (kb) {
      kb.on('keydown-UP', () => this.world.setEnemyTarget(this.world.enemyTarget + 100));
      kb.on('keydown-DOWN', () => this.world.setEnemyTarget(this.world.enemyTarget - 100));
      kb.on('keydown-RIGHT', () => (this.world.fireRateMul = Math.min(32, this.world.fireRateMul * 2)));
      kb.on('keydown-LEFT', () => (this.world.fireRateMul = Math.max(0.25, this.world.fireRateMul / 2)));
      kb.on('keydown-R', () => this.toggleRender());
    }
  }

  private makeTextures(): void {
    const g = this.make.graphics({ x: 0, y: 0 }, false);
    const circle = (key: string, color: number, r: number) => {
      g.clear();
      g.fillStyle(color, 1);
      g.fillCircle(r, r, r);
      g.generateTexture(key, r * 2, r * 2);
    };
    circle('enemy', 0xe05555, 12);
    circle('bullet', 0xffe066, 5);
    circle('coin', 0xf5c542, 6);
    circle('player', 0x55e07a, 14);
    g.clear();
    g.fillStyle(0x5599ff, 1);
    g.fillRect(0, 0, 24, 24);
    g.generateTexture('tower', 24, 24);
    g.destroy();
  }

  private makePool(n: number, key: string): Phaser.GameObjects.Image[] {
    const pool: Phaser.GameObjects.Image[] = [];
    for (let i = 0; i < n; i++) pool.push(this.add.image(0, 0, key).setVisible(false));
    return pool;
  }

  private fitCamera(): void {
    const cam = this.cameras.main;
    cam.setZoom(Math.min(this.scale.width / MAP_W, this.scale.height / MAP_H));
    cam.centerOn(MAP_W / 2, MAP_H / 2);
  }

  private toggleRender(): void {
    this.renderOn = !this.renderOn;
    if (!this.renderOn) {
      for (const s of this.enemySprites) s.setVisible(false);
      for (const s of this.bulletSprites) s.setVisible(false);
      for (const s of this.coinSprites) s.setVisible(false);
    }
  }

  update(_time: number, delta: number): void {
    // 固定タイムステップ:描画が重くてもロジックの進み方は変わらない
    this.acc += Math.min(delta, 100) / 1000;
    const t0 = performance.now();
    let steps = 0;
    while (this.acc >= TICK && steps < 4) {
      this.world.step(TICK);
      this.acc -= TICK;
      steps++;
    }
    if (steps === 4) this.acc = 0; // 追いつけない場合は遅れを捨てる
    const t1 = performance.now();
    if (this.renderOn) this.syncSprites();
    const t2 = performance.now();

    this.simSum += t1 - t0;
    this.simMax = Math.max(this.simMax, t1 - t0);
    this.syncSum += t2 - t1;
    this.frames++;
    this.hudTimer += delta;
    if (this.hudTimer >= 500) this.updateHud();
  }

  private syncSprites(): void {
    const w = this.world;
    for (let i = 0; i < MAX_ENEMIES; i++) {
      const s = this.enemySprites[i];
      if (w.ealive[i]) {
        s.setPosition(w.ex[i], w.ey[i]);
        if (!s.visible) s.setVisible(true);
      } else if (s.visible) {
        s.setVisible(false);
      }
    }
    for (let i = 0; i < MAX_BULLETS; i++) {
      const s = this.bulletSprites[i];
      if (w.balive[i]) {
        s.setPosition(w.bx[i], w.by[i]);
        if (!s.visible) s.setVisible(true);
      } else if (s.visible) {
        s.setVisible(false);
      }
    }
    for (let i = 0; i < MAX_COINS; i++) {
      const s = this.coinSprites[i];
      if (w.calive[i]) {
        s.setPosition(w.cx[i], w.cy[i]);
        if (!s.visible) s.setVisible(true);
      } else if (s.visible) {
        s.setVisible(false);
      }
    }
    this.playerSprite.setPosition(w.px, w.py);
  }

  private updateHud(): void {
    const w = this.world;
    const f = Math.max(1, this.frames);
    const fps = this.game.loop.actualFps;
    this.hud.textContent =
      `FPS ${fps.toFixed(1)}  (目標 60)\n` +
      `ロジック ${(this.simSum / f).toFixed(2)}ms/フレーム (最大 ${this.simMax.toFixed(2)}ms)\n` +
      `スプライト同期 ${(this.syncSum / f).toFixed(2)}ms/フレーム  描画 ${this.renderOn ? 'ON' : 'OFF'}\n` +
      `敵 ${w.enemyCount}/${w.enemyTarget}  弾 ${w.bulletCount}/${MAX_BULLETS}  通貨 ${w.coinCount}/${MAX_COINS}\n` +
      `発射速度 ×${w.fireRateMul}  撃破 ${w.kills}  通貨統合 ${w.mergedDrops}\n` +
      `[↑↓]敵数±100 [←→]発射速度 [R]描画ON/OFF`;
    this.simSum = 0;
    this.simMax = 0;
    this.syncSum = 0;
    this.frames = 0;
    this.hudTimer = 0;
  }
}
