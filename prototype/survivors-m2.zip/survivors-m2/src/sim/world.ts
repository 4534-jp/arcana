import {
  BULLET, CELL, COIN, CRIT_MUL, ENEMY_BULLET, ENEMY_TYPES, MAP_H, MAP_W, MAX_BLAST, MAX_BULLETS, MAX_COINS,
  MAX_DN, MAX_EBULLETS, MAX_ENEMIES, MAX_ENEMY_RADIUS, MAX_PENDING, MAX_SLASH, MAX_TOWERS, PLAYER, SEPARATION,
  SPAWN, SPAWN_MIX, TOWER, WEAPONS,
  type WeaponDef,
} from './config';
import { SpatialHash } from './spatialHash';

/** 再現性のある乱数(seed固定)。 */
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** 空き番号を管理するプール(確保・解放が O(1))。 */
class IndexPool {
  private readonly stack: Int32Array;
  private top: number;
  constructor(readonly size: number) {
    this.stack = new Int32Array(size);
    this.top = size;
    for (let i = 0; i < size; i++) this.stack[i] = size - 1 - i;
  }
  alloc(): number {
    return this.top > 0 ? this.stack[--this.top] : -1;
  }
  free(i: number): void {
    this.stack[this.top++] = i;
  }
  get used(): number {
    return this.size - this.top;
  }
}

/** 個体値(0.5〜1.0)。武器のステータスごとに持つ。 */
export interface IndividualValues {
  damage: number;
  speed: number;
  range: number;
  crit: number;
  knockback: number;
}

/** 個体値を反映した、実際に使う武器。 */
export interface Weapon {
  def: WeaponDef;
  iv: IndividualValues;
  damage: number;
  interval: number;
  range: number;
  crit: number;
  knockback: number;
}

/** プレイヤーのステータス(M2では全て0)。最終値 = ((P×k + 武器値×m_w) × m_all) の P の部分。 */
export interface PlayerStats {
  damageMelee: number;
  damageRanged: number;
  damageMagic: number;
  defense: number; // 被ダメージ = 元 / (1 + 防御力/100)
  weaponMul: number; // 武器のみにかかる倍率 m_w
  allMul: number; // 全体にかかる倍率 m_all
}

export interface WorldOptions {
  seed?: number;
  weaponId?: string;
  towers?: number; // 0〜20(M1の負荷検証用)
  godMode?: boolean; // プレイヤーが死なない
  autoOrbit?: boolean; // 入力ではなく円軌道で動く(ベンチ用)
  ivFixed?: number; // 個体値を固定する(検証用)
  freezeEnemies?: boolean; // 敵が動かず攻撃もしない(検証用)
}

/** 描画に依存しない純粋なシミュレーション。Phaserは一切importしない。 */
export class World {
  // ---- 敵 ----
  readonly ex = new Float32Array(MAX_ENEMIES);
  readonly ey = new Float32Array(MAX_ENEMIES);
  readonly ehp = new Float32Array(MAX_ENEMIES);
  readonly etype = new Uint8Array(MAX_ENEMIES);
  readonly ealive = new Uint8Array(MAX_ENEMIES);
  private readonly ekx = new Float32Array(MAX_ENEMIES);
  private readonly eky = new Float32Array(MAX_ENEMIES);
  private readonly eatk = new Float32Array(MAX_ENEMIES);
  private readonly sepx = new Float32Array(MAX_ENEMIES);
  private readonly sepy = new Float32Array(MAX_ENEMIES);
  readonly typeCount = new Int32Array(ENEMY_TYPES.length);
  // ---- 出現予告中の敵 ----
  readonly mx = new Float32Array(MAX_PENDING);
  readonly my = new Float32Array(MAX_PENDING);
  readonly mt = new Float32Array(MAX_PENDING); // 残り時間
  readonly mtot = new Float32Array(MAX_PENDING); // 予告の全体時間
  readonly mtype = new Uint8Array(MAX_PENDING);
  readonly malive = new Uint8Array(MAX_PENDING);
  // ---- タワー(M1の負荷検証用) ----
  readonly tx = new Float32Array(MAX_TOWERS);
  readonly ty = new Float32Array(MAX_TOWERS);
  private readonly tcool = new Float32Array(MAX_TOWERS);
  readonly towerCount: number;
  // ---- プレイヤー・タワーの弾 ----
  readonly bx = new Float32Array(MAX_BULLETS);
  readonly by = new Float32Array(MAX_BULLETS);
  private readonly bvx = new Float32Array(MAX_BULLETS);
  private readonly bvy = new Float32Array(MAX_BULLETS);
  private readonly blife = new Float32Array(MAX_BULLETS);
  private readonly bdmg = new Float32Array(MAX_BULLETS);
  private readonly bkb = new Float32Array(MAX_BULLETS);
  private readonly bcrit = new Uint8Array(MAX_BULLETS);
  readonly bkind = new Uint8Array(MAX_BULLETS); // 0=矢・タワー弾 1=ファイヤーボール
  readonly balive = new Uint8Array(MAX_BULLETS);
  // ---- 敵の弾 ----
  readonly fx = new Float32Array(MAX_EBULLETS);
  readonly fy = new Float32Array(MAX_EBULLETS);
  private readonly fvx = new Float32Array(MAX_EBULLETS);
  private readonly fvy = new Float32Array(MAX_EBULLETS);
  private readonly flife = new Float32Array(MAX_EBULLETS);
  private readonly fdmg = new Float32Array(MAX_EBULLETS);
  private readonly ftarget = new Int16Array(MAX_EBULLETS); // 0=プレイヤー 1+n=タワーn
  readonly falive = new Uint8Array(MAX_EBULLETS);
  // ---- 通貨(近くの通貨は統合) ----
  readonly cx = new Float32Array(MAX_COINS);
  readonly cy = new Float32Array(MAX_COINS);
  readonly cval = new Float32Array(MAX_COINS);
  readonly calive = new Uint8Array(MAX_COINS);
  // ---- ダメージ数字(リング。超過時は古いものから上書き) ----
  readonly dnx = new Float32Array(MAX_DN);
  readonly dny = new Float32Array(MAX_DN);
  readonly dnv = new Float32Array(MAX_DN);
  readonly dnlife = new Float32Array(MAX_DN);
  readonly dncrit = new Uint8Array(MAX_DN);
  readonly dnid = new Uint32Array(MAX_DN); // 内容が変わったかの判定用
  private dnHead = 0;
  private dnSeq = 1;
  // ---- エフェクト ----
  readonly blX = new Float32Array(MAX_BLAST);
  readonly blY = new Float32Array(MAX_BLAST);
  readonly blR = new Float32Array(MAX_BLAST);
  readonly blLife = new Float32Array(MAX_BLAST);
  private blHead = 0;
  readonly slX = new Float32Array(MAX_SLASH);
  readonly slY = new Float32Array(MAX_SLASH);
  readonly slAng = new Float32Array(MAX_SLASH);
  readonly slR = new Float32Array(MAX_SLASH);
  readonly slLife = new Float32Array(MAX_SLASH);
  private slHead = 0;

  // ---- プレイヤー ----
  px = MAP_W / 2;
  py = MAP_H / 2;
  hp = PLAYER.maxHp;
  readonly maxHp = PLAYER.maxHp;
  dead = false;
  hurtFlash = 0;
  readonly weapon: Weapon;
  readonly stats: PlayerStats = {
    damageMelee: 0, damageRanged: 0, damageMagic: 0, defense: 0, weaponMul: 1, allMul: 1,
  };
  private pcool = 0;
  private pAngle = 0;

  // ---- 設定(実行中に変更できる) ----
  enemyTarget = 40;
  towerFireMul = 1;
  markerTime = SPAWN.markerTime;
  separationOn = true;
  damageNumbersOn = true;
  armorScale = 1; // 小ダメージ軽減の閾値の倍率(ウェーブ進行で伸ばす想定)
  readonly godMode: boolean;
  readonly autoOrbit: boolean;
  private readonly freeze: boolean;

  // ---- 統計 ----
  time = 0;
  kills = 0;
  gold = 0;
  mergedDrops = 0;
  contactHits = 0;
  damageTaken = 0;

  private readonly enemyPool = new IndexPool(MAX_ENEMIES);
  private readonly pendingPool = new IndexPool(MAX_PENDING);
  private readonly bulletPool = new IndexPool(MAX_BULLETS);
  private readonly ebulletPool = new IndexPool(MAX_EBULLETS);
  private readonly coinPool = new IndexPool(MAX_COINS);
  private readonly hash = new SpatialHash(MAP_W, MAP_H, CELL, MAX_ENEMIES);
  private readonly buf = new Int32Array(MAX_ENEMIES);
  private readonly buf2 = new Int32Array(MAX_ENEMIES);
  private readonly rng: () => number;
  private spawnX = 0;
  private spawnY = 0;

  constructor(opts: WorldOptions = {}) {
    this.rng = mulberry32(opts.seed ?? 1);
    this.godMode = opts.godMode ?? false;
    this.autoOrbit = opts.autoOrbit ?? false;
    this.freeze = opts.freezeEnemies ?? false;
    this.towerCount = Math.max(0, Math.min(MAX_TOWERS, opts.towers ?? 0));
    const rows = Math.ceil(MAX_TOWERS / TOWER.cols);
    for (let i = 0; i < MAX_TOWERS; i++) {
      const col = i % TOWER.cols;
      const row = Math.floor(i / TOWER.cols);
      this.tx[i] = MAP_W / 2 + (col - (TOWER.cols - 1) / 2) * TOWER.spacing;
      this.ty[i] = MAP_H / 2 + (row - (rows - 1) / 2) * TOWER.spacing;
      this.tcool[i] = this.rng() * TOWER.interval;
    }
    this.weapon = this.makeWeapon(opts.weaponId ?? 'bow', opts.ivFixed);
  }

  get enemyCount(): number { return this.enemyPool.used; }
  get pendingCount(): number { return this.pendingPool.used; }
  get bulletCount(): number { return this.bulletPool.used; }
  get ebulletCount(): number { return this.ebulletPool.used; }
  get coinCount(): number { return this.coinPool.used; }

  setEnemyTarget(n: number): void {
    this.enemyTarget = Math.max(0, Math.min(MAX_ENEMIES, n));
  }

  /** 個体値を抽選して、実際に使う武器を作る。 */
  private makeWeapon(id: string, fixed?: number): Weapon {
    const def = WEAPONS.find((w) => w.id === id) ?? WEAPONS[1];
    const roll = () => fixed ?? 0.5 + 0.5 * this.rng();
    const iv: IndividualValues = { damage: roll(), speed: roll(), range: roll(), crit: roll(), knockback: roll() };
    return {
      def, iv,
      damage: def.damage * iv.damage,
      interval: def.interval / iv.speed,
      range: def.range * iv.range,
      crit: def.crit * iv.crit,
      knockback: def.knockback * iv.knockback,
    };
  }

  /** 検証・テスト用:敵を直接出す。 */
  debugSpawn(type: number, x: number, y: number): void {
    this.spawnEnemy(x, y, type);
  }

  step(dt: number, ix = 0, iy = 0): void {
    if (this.dead) return;
    this.time += dt;
    this.updatePlayer(dt, ix, iy);
    this.updatePending(dt);
    this.requestSpawns();
    this.rebuildHash();
    if (!this.freeze) {
      this.updateEnemies(dt);
      if (this.separationOn) this.separate();
    }
    this.updatePlayerWeapon(dt);
    this.updateTowers(dt);
    this.updatePlayerBullets(dt);
    this.updateEnemyBullets(dt);
    this.updateCoins();
    this.updateEffects(dt);
  }

  // ================= プレイヤー =================
  private updatePlayer(dt: number, ix: number, iy: number): void {
    if (this.autoOrbit) {
      this.pAngle += (PLAYER.speed / PLAYER.orbitRadius) * dt;
      this.px = MAP_W / 2 + Math.cos(this.pAngle) * PLAYER.orbitRadius;
      this.py = MAP_H / 2 + Math.sin(this.pAngle) * PLAYER.orbitRadius;
    } else {
      const len = Math.sqrt(ix * ix + iy * iy);
      if (len > 0) {
        const s = (PLAYER.speed * dt) / len; // 斜め移動でも速さを一定にする
        this.px = Math.max(PLAYER.radius, Math.min(MAP_W - PLAYER.radius, this.px + ix * s));
        this.py = Math.max(PLAYER.radius, Math.min(MAP_H - PLAYER.radius, this.py + iy * s));
      }
    }
    if (this.hurtFlash > 0) this.hurtFlash -= dt;
  }

  private damagePlayer(d: number): void {
    if (this.godMode) return;
    const real = d / (1 + this.stats.defense / 100);
    this.hp -= real;
    this.damageTaken += real;
    this.hurtFlash = 0.15;
    if (this.hp <= 0) {
      this.hp = 0;
      this.dead = true;
    }
  }

  /** 最終ダメージ = ((プレイヤーの素のステータス + 武器の素の値 × m_w) × m_all) */
  private weaponDamage(): number {
    const w = this.weapon;
    const s = this.stats;
    const p = w.def.kind === 'melee' ? s.damageMelee : w.def.kind === 'arrow' ? s.damageRanged : s.damageMagic;
    return (p + w.damage * s.weaponMul) * s.allMul;
  }

  // ================= 敵の出現(予告マーカーつき) =================
  private pickType(): number {
    let r = this.rng();
    for (let t = 0; t < SPAWN_MIX.length; t++) {
      r -= SPAWN_MIX[t];
      if (r < 0) return t;
    }
    return 0;
  }

  private requestSpawns(): void {
    let budget = SPAWN.perTick;
    while (budget-- > 0 && this.enemyPool.used + this.pendingPool.used < this.enemyTarget) {
      this.findSpawnPoint();
      const type = this.pickType();
      if (this.markerTime <= 0) {
        this.spawnEnemy(this.spawnX, this.spawnY, type);
      } else {
        const m = this.pendingPool.alloc();
        if (m < 0) break;
        this.mx[m] = this.spawnX;
        this.my[m] = this.spawnY;
        this.mt[m] = this.markerTime;
        this.mtot[m] = this.markerTime;
        this.mtype[m] = type;
        this.malive[m] = 1;
      }
    }
  }

  private updatePending(dt: number): void {
    for (let m = 0; m < MAX_PENDING; m++) {
      if (!this.malive[m]) continue;
      this.mt[m] -= dt;
      if (this.mt[m] <= 0) {
        this.spawnEnemy(this.mx[m], this.my[m], this.mtype[m]);
        this.malive[m] = 0;
        this.pendingPool.free(m);
      }
    }
  }

  private findSpawnPoint(): void {
    for (let a = 0; a < SPAWN.attempts; a++) {
      const x = this.rng() * MAP_W;
      const y = this.rng() * MAP_H;
      if (this.isValidSpawn(x, y)) {
        this.spawnX = x;
        this.spawnY = y;
        return;
      }
    }
    // 有効地点が見つからない場合はマップ端(本番では強制スポーン領域に置き換える)
    const t = this.rng() * 2 * (MAP_W + MAP_H);
    if (t < MAP_W) { this.spawnX = t; this.spawnY = 0; }
    else if (t < MAP_W + MAP_H) { this.spawnX = MAP_W; this.spawnY = t - MAP_W; }
    else if (t < 2 * MAP_W + MAP_H) { this.spawnX = t - MAP_W - MAP_H; this.spawnY = MAP_H; }
    else { this.spawnX = 0; this.spawnY = t - 2 * MAP_W - MAP_H; }
  }

  private isValidSpawn(x: number, y: number): boolean {
    let dx = x - this.px;
    let dy = y - this.py;
    if (dx * dx + dy * dy < SPAWN.playerExclusion * SPAWN.playerExclusion) return false;
    const r2 = SPAWN.towerExclusion * SPAWN.towerExclusion;
    for (let t = 0; t < this.towerCount; t++) {
      dx = x - this.tx[t];
      dy = y - this.ty[t];
      if (dx * dx + dy * dy < r2) return false;
    }
    return true;
  }

  private spawnEnemy(x: number, y: number, type: number): void {
    const i = this.enemyPool.alloc();
    if (i < 0) return;
    const d = ENEMY_TYPES[type];
    this.ex[i] = x;
    this.ey[i] = y;
    this.ehp[i] = d.hp;
    this.etype[i] = type;
    this.ealive[i] = 1;
    this.ekx[i] = 0;
    this.eky[i] = 0;
    this.eatk[i] = d.shotInterval > 0 ? this.rng() * d.shotInterval : this.rng() * 0.5;
    this.typeCount[type]++;
  }

  private removeEnemy(i: number): void {
    this.ealive[i] = 0;
    this.typeCount[this.etype[i]]--;
    this.enemyPool.free(i);
  }

  private rebuildHash(): void {
    this.hash.clear();
    for (let i = 0; i < MAX_ENEMIES; i++) {
      if (this.ealive[i]) this.hash.insert(i, this.ex[i], this.ey[i]);
    }
  }

  // ================= 敵の行動 =================
  private updateEnemies(dt: number): void {
    const decay = SEPARATION.knockbackDecay;
    for (let i = 0; i < MAX_ENEMIES; i++) {
      if (!this.ealive[i]) continue;
      const def = ENEMY_TYPES[this.etype[i]];
      let x = this.ex[i];
      let y = this.ey[i];

      // 最寄りの標的(プレイヤー+タワー)
      let tid = 0;
      let tgx = this.px;
      let tgy = this.py;
      let bd = (x - tgx) * (x - tgx) + (y - tgy) * (y - tgy);
      for (let t = 0; t < this.towerCount; t++) {
        const dx = x - this.tx[t];
        const dy = y - this.ty[t];
        const d2 = dx * dx + dy * dy;
        if (d2 < bd) { bd = d2; tid = t + 1; tgx = this.tx[t]; tgy = this.ty[t]; }
      }
      const dist = Math.sqrt(bd);
      this.eatk[i] -= dt;

      let move = true;
      if (def.shotDmg > 0) {
        // 遠距離:射程に入ったら止まって撃つ
        if (dist <= def.shotRange) {
          move = false;
          if (this.eatk[i] <= 0) {
            this.fireEnemyBullet(x, y, tgx, tgy, def.shotDmg, def.shotSpeed, tid);
            this.eatk[i] = def.shotInterval;
          }
        }
      } else {
        const reach = def.radius + (tid === 0 ? PLAYER.radius : 12) + 2;
        if (dist <= reach) {
          move = false;
          if (tid === 0) {
            if (this.eatk[i] <= 0) {
              this.damagePlayer(def.contactDmg);
              this.eatk[i] = def.contactInterval;
            }
          } else {
            // タワーに到達した敵は消える(M1の負荷検証と同じ。タワーのHPはM3で実装)
            this.contactHits++;
            this.removeEnemy(i);
            continue;
          }
        }
      }

      if (move && dist > 0) {
        const s = (def.speed * dt) / dist;
        x += (tgx - x) * s;
        y += (tgy - y) * s;
      }
      // ノックバック
      x += this.ekx[i] * dt;
      y += this.eky[i] * dt;
      this.ekx[i] *= decay;
      this.eky[i] *= decay;
      this.ex[i] = x < 0 ? 0 : x > MAP_W ? MAP_W : x;
      this.ey[i] = y < 0 ? 0 : y > MAP_H ? MAP_H : y;
    }
  }

  /** 敵同士の軽い分離:重なった敵を、重さに応じて押し離す。 */
  private separate(): void {
    this.sepx.fill(0);
    this.sepy.fill(0);
    for (let i = 0; i < MAX_ENEMIES; i++) {
      if (!this.ealive[i]) continue;
      const di = ENEMY_TYPES[this.etype[i]];
      const xi = this.ex[i];
      const yi = this.ey[i];
      const n = this.hash.query(xi, yi, di.radius + MAX_ENEMY_RADIUS, this.buf2);
      for (let k = 0; k < n; k++) {
        const j = this.buf2[k];
        if (j <= i || !this.ealive[j]) continue;
        const dj = ENEMY_TYPES[this.etype[j]];
        let dx = this.ex[j] - xi;
        let dy = this.ey[j] - yi;
        const minD = di.radius + dj.radius;
        let d2 = dx * dx + dy * dy;
        if (d2 >= minD * minD) continue;
        if (d2 < 1e-6) { // 完全に重なっている場合はランダムな向きに
          const a = this.rng() * 6.2831853;
          dx = Math.cos(a);
          dy = Math.sin(a);
          d2 = 1;
        }
        const d = Math.sqrt(d2);
        const push = (minD - d) * SEPARATION.stiffness;
        const nx = dx / d;
        const ny = dy / d;
        const si = dj.mass / (di.mass + dj.mass); // 軽い方がより動く
        const sj = 1 - si;
        this.sepx[i] -= nx * push * si;
        this.sepy[i] -= ny * push * si;
        this.sepx[j] += nx * push * sj;
        this.sepy[j] += ny * push * sj;
      }
    }
    const max = SEPARATION.maxPush;
    for (let i = 0; i < MAX_ENEMIES; i++) {
      if (!this.ealive[i]) continue;
      let ux = this.sepx[i];
      let uy = this.sepy[i];
      const m = Math.sqrt(ux * ux + uy * uy);
      if (m > max) { ux = (ux / m) * max; uy = (uy / m) * max; }
      this.ex[i] += ux;
      this.ey[i] += uy;
    }
  }

  // ================= ダメージ処理 =================
  /** 敵にダメージを与える。クリティカル → 小ダメージ軽減 → HP減少 → ノックバック → 撃破判定。 */
  private hitEnemy(e: number, dmg: number, crit: boolean, nx: number, ny: number, kb: number): void {
    const def = ENEMY_TYPES[this.etype[e]];
    let d = crit ? dmg * CRIT_MUL : dmg;
    if (def.armorT > 0) {
      const T = def.armorT * this.armorScale;
      d *= Math.min(1, d / T); // 1発が閾値未満なら、その割合だけ通る
    }
    this.ehp[e] -= d;
    this.pushDamageNumber(this.ex[e], this.ey[e] - def.radius, d, crit);
    if (kb > 0) {
      const k = kb * (1 - def.kbResist);
      this.ekx[e] += nx * k;
      this.eky[e] += ny * k;
    }
    if (this.ehp[e] <= 0) this.killEnemy(e);
  }

  private killEnemy(e: number): void {
    this.kills++;
    this.dropCoin(this.ex[e], this.ey[e], ENEMY_TYPES[this.etype[e]].reward);
    this.removeEnemy(e);
  }

  private pushDamageNumber(x: number, y: number, v: number, crit: boolean): void {
    if (!this.damageNumbersOn) return;
    const i = this.dnHead;
    this.dnHead = (i + 1) % MAX_DN;
    this.dnx[i] = x;
    this.dny[i] = y;
    this.dnv[i] = v;
    this.dncrit[i] = crit ? 1 : 0;
    this.dnlife[i] = 0.7;
    this.dnid[i] = this.dnSeq++;
  }

  // ================= プレイヤーの武器 =================
  private nearestEnemy(x: number, y: number, range: number): number {
    const n = this.hash.query(x, y, range + MAX_ENEMY_RADIUS, this.buf);
    let best = -1;
    let bd = Infinity;
    for (let k = 0; k < n; k++) {
      const e = this.buf[k];
      if (!this.ealive[e]) continue;
      const dx = this.ex[e] - x;
      const dy = this.ey[e] - y;
      const d = dx * dx + dy * dy;
      const r = range + ENEMY_TYPES[this.etype[e]].radius;
      if (d <= r * r && d < bd) { bd = d; best = e; }
    }
    return best;
  }

  private updatePlayerWeapon(dt: number): void {
    this.pcool -= dt;
    if (this.pcool > 0) return;
    const w = this.weapon;
    const e = this.nearestEnemy(this.px, this.py, w.range);
    if (e < 0) { this.pcool = 0; return; }
    const dx = this.ex[e] - this.px;
    const dy = this.ey[e] - this.py;
    const len = Math.sqrt(dx * dx + dy * dy) || 1;
    const nx = dx / len;
    const ny = dy / len;
    const dmg = this.weaponDamage();
    const kind = w.def.kind;
    if (kind === 'melee') {
      this.swing(nx, ny, dmg);
    } else if (kind === 'arrow') {
      this.fire(this.px, this.py, nx, ny, dmg, this.rng() < w.crit, 0, w.def.projSpeed, BULLET.life * 1.2, w.knockback);
    } else {
      this.fire(this.px, this.py, nx, ny, dmg, false, 1, w.def.projSpeed, w.range / w.def.projSpeed, 0);
    }
    this.pcool = w.interval;
  }

  /** 近接:前方の扇形にいる敵すべてに当てる。 */
  private swing(nx: number, ny: number, dmg: number): void {
    const w = this.weapon;
    const range = w.range;
    const cosHalf = Math.cos((w.def.arcHalfDeg * Math.PI) / 180);
    const n = this.hash.query(this.px, this.py, range + MAX_ENEMY_RADIUS, this.buf);
    for (let k = 0; k < n; k++) {
      const e = this.buf[k];
      if (!this.ealive[e]) continue;
      const dx = this.ex[e] - this.px;
      const dy = this.ey[e] - this.py;
      const d2 = dx * dx + dy * dy;
      const r = range + ENEMY_TYPES[this.etype[e]].radius;
      if (d2 > r * r) continue;
      const d = Math.sqrt(d2) || 1;
      if ((dx * nx + dy * ny) / d < cosHalf) continue;
      this.hitEnemy(e, dmg, this.rng() < w.crit, dx / d, dy / d, w.knockback);
    }
    const i = this.slHead;
    this.slHead = (i + 1) % MAX_SLASH;
    this.slX[i] = this.px;
    this.slY[i] = this.py;
    this.slAng[i] = Math.atan2(ny, nx);
    this.slR[i] = range;
    this.slLife[i] = 0.15;
  }

  private fire(
    x: number, y: number, nx: number, ny: number, dmg: number, crit: boolean,
    kind: number, speed: number, life: number, kb: number,
  ): void {
    const b = this.bulletPool.alloc();
    if (b < 0) return; // 上限超過分は発射を見送る
    this.bx[b] = x;
    this.by[b] = y;
    this.bvx[b] = nx * speed;
    this.bvy[b] = ny * speed;
    this.blife[b] = life;
    this.bdmg[b] = dmg;
    this.bkb[b] = kb;
    this.bcrit[b] = crit ? 1 : 0;
    this.bkind[b] = kind;
    this.balive[b] = 1;
  }

  private removeBullet(b: number): void {
    this.balive[b] = 0;
    this.bulletPool.free(b);
  }

  private updatePlayerBullets(dt: number): void {
    for (let b = 0; b < MAX_BULLETS; b++) {
      if (!this.balive[b]) continue;
      const x = (this.bx[b] += this.bvx[b] * dt);
      const y = (this.by[b] += this.bvy[b] * dt);
      this.blife[b] -= dt;
      const isBall = this.bkind[b] === 1;
      const outside = x < 0 || y < 0 || x > MAP_W || y > MAP_H;
      if (this.blife[b] <= 0 || outside) {
        if (isBall) this.explode(x, y, b); // ファイヤーボールは射程の終わりでも爆発する
        this.removeBullet(b);
        continue;
      }
      const br = isBall ? BULLET.fireballRadius : BULLET.radius;
      const n = this.hash.query(x, y, br + MAX_ENEMY_RADIUS, this.buf);
      for (let k = 0; k < n; k++) {
        const e = this.buf[k];
        if (!this.ealive[e]) continue;
        const dx = this.ex[e] - x;
        const dy = this.ey[e] - y;
        const r = br + ENEMY_TYPES[this.etype[e]].radius;
        if (dx * dx + dy * dy > r * r) continue;
        if (isBall) {
          this.explode(x, y, b);
        } else {
          const sp = Math.sqrt(this.bvx[b] * this.bvx[b] + this.bvy[b] * this.bvy[b]) || 1;
          this.hitEnemy(e, this.bdmg[b], this.bcrit[b] === 1, this.bvx[b] / sp, this.bvy[b] / sp, this.bkb[b]);
        }
        this.removeBullet(b);
        break;
      }
    }
  }

  /** ファイヤーボールの爆発:範囲内の全員にダメージ。 */
  private explode(x: number, y: number, b: number): void {
    const R = this.weapon.def.blastRadius;
    const dmg = this.bdmg[b];
    const n = this.hash.query(x, y, R + MAX_ENEMY_RADIUS, this.buf);
    for (let k = 0; k < n; k++) {
      const e = this.buf[k];
      if (!this.ealive[e]) continue;
      const dx = this.ex[e] - x;
      const dy = this.ey[e] - y;
      const r = R + ENEMY_TYPES[this.etype[e]].radius;
      const d2 = dx * dx + dy * dy;
      if (d2 > r * r) continue;
      const d = Math.sqrt(d2) || 1;
      this.hitEnemy(e, dmg, this.rng() < this.weapon.crit, dx / d, dy / d, this.bkb[b]);
    }
    const i = this.blHead;
    this.blHead = (i + 1) % MAX_BLAST;
    this.blX[i] = x;
    this.blY[i] = y;
    this.blR[i] = R;
    this.blLife[i] = 0.2;
  }

  // ================= タワー(M1の負荷検証用) =================
  private updateTowers(dt: number): void {
    for (let t = 0; t < this.towerCount; t++) {
      this.tcool[t] -= dt;
      if (this.tcool[t] > 0) continue;
      const e = this.nearestEnemy(this.tx[t], this.ty[t], TOWER.range);
      if (e >= 0) {
        const dx = this.ex[e] - this.tx[t];
        const dy = this.ey[e] - this.ty[t];
        const len = Math.sqrt(dx * dx + dy * dy) || 1;
        this.fire(this.tx[t], this.ty[t], dx / len, dy / len, TOWER.damage, false, 0, BULLET.speed, BULLET.life, 0);
        this.tcool[t] = TOWER.interval / this.towerFireMul;
      } else {
        this.tcool[t] = 0;
      }
    }
  }

  // ================= 敵の弾 =================
  private fireEnemyBullet(x: number, y: number, tx: number, ty: number, dmg: number, speed: number, target: number): void {
    const f = this.ebulletPool.alloc();
    if (f < 0) return; // 上限超過分は発射を見送る
    const dx = tx - x;
    const dy = ty - y;
    const len = Math.sqrt(dx * dx + dy * dy) || 1;
    this.fx[f] = x;
    this.fy[f] = y;
    this.fvx[f] = (dx / len) * speed;
    this.fvy[f] = (dy / len) * speed;
    this.flife[f] = ENEMY_BULLET.life;
    this.fdmg[f] = dmg;
    this.ftarget[f] = target;
    this.falive[f] = 1;
  }

  /** 敵の弾は、狙った対象にだけ当たる(他のものとは衝突しない)。 */
  private updateEnemyBullets(dt: number): void {
    for (let f = 0; f < MAX_EBULLETS; f++) {
      if (!this.falive[f]) continue;
      const x = (this.fx[f] += this.fvx[f] * dt);
      const y = (this.fy[f] += this.fvy[f] * dt);
      this.flife[f] -= dt;
      const id = this.ftarget[f];
      let gone = this.flife[f] <= 0 || x < 0 || y < 0 || x > MAP_W || y > MAP_H;
      if (!gone) {
        const tgx = id === 0 ? this.px : this.tx[id - 1];
        const tgy = id === 0 ? this.py : this.ty[id - 1];
        const r = ENEMY_BULLET.radius + (id === 0 ? PLAYER.radius : 12);
        const dx = tgx - x;
        const dy = tgy - y;
        if (dx * dx + dy * dy <= r * r) {
          if (id === 0) this.damagePlayer(this.fdmg[f]);
          gone = true;
        }
      }
      if (gone) {
        this.falive[f] = 0;
        this.ebulletPool.free(f);
      }
    }
  }

  // ================= 通貨(近くに既存の通貨があれば値を加算して新規ドロップしない) =================
  private dropCoin(x: number, y: number, value: number): void {
    const m2 = COIN.mergeRadius * COIN.mergeRadius;
    let near = -1;
    let nd = Infinity;
    for (let c = 0; c < MAX_COINS; c++) {
      if (!this.calive[c]) continue;
      const dx = this.cx[c] - x;
      const dy = this.cy[c] - y;
      const d = dx * dx + dy * dy;
      if (d < nd) { nd = d; near = c; }
    }
    if (near >= 0 && nd <= m2) {
      this.cval[near] += value;
      this.mergedDrops++;
      return;
    }
    const c = this.coinPool.alloc();
    if (c < 0) {
      if (near >= 0) { this.cval[near] += value; this.mergedDrops++; }
      return;
    }
    this.cx[c] = x;
    this.cy[c] = y;
    this.cval[c] = value;
    this.calive[c] = 1;
  }

  private updateCoins(): void {
    const r2 = PLAYER.pickupRadius * PLAYER.pickupRadius;
    for (let c = 0; c < MAX_COINS; c++) {
      if (!this.calive[c]) continue;
      const dx = this.cx[c] - this.px;
      const dy = this.cy[c] - this.py;
      if (dx * dx + dy * dy <= r2) {
        this.gold += this.cval[c];
        this.calive[c] = 0;
        this.coinPool.free(c);
      }
    }
  }

  // ================= エフェクトの寿命 =================
  private updateEffects(dt: number): void {
    for (let i = 0; i < MAX_DN; i++) {
      if (this.dnlife[i] > 0) {
        this.dnlife[i] -= dt;
        this.dny[i] -= 40 * dt; // 上に浮かぶ
      }
    }
    for (let i = 0; i < MAX_BLAST; i++) if (this.blLife[i] > 0) this.blLife[i] -= dt;
    for (let i = 0; i < MAX_SLASH; i++) if (this.slLife[i] > 0) this.slLife[i] -= dt;
  }
}
