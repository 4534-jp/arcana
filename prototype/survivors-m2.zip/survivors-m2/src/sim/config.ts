// ゲームロジックの定数(すべて仮の数値)。バランス調整はここを変える。
export const MAP_W = 3840;
export const MAP_H = 2160;
export const TICK = 1 / 60; // 固定タイムステップ(秒)
export const CELL = 64; // 空間ハッシュのセルサイズ(px)

// 配列の確保サイズ(同時存在数の上限)
export const MAX_ENEMIES = 1000;
export const MAX_PENDING = 300; // 出現予告中の敵
export const MAX_BULLETS = 300; // プレイヤー・タワーの弾
export const MAX_EBULLETS = 200; // 敵の弾
export const MAX_COINS = 300;
export const MAX_DN = 100; // ダメージ数字(超過時は古いものから消す)
export const MAX_BLAST = 64; // 爆発エフェクト
export const MAX_SLASH = 8; // 斬撃エフェクト
export const MAX_TOWERS = 20;

export const CRIT_MUL = 2; // クリティカル倍率(暫定)
export const MAX_ENEMY_RADIUS = 18;

export const PLAYER = { maxHp: 10, radius: 14, speed: 300, pickupRadius: 80, orbitRadius: 250 };

/** 敵の種類。id は etype 配列の値と一致させる。 */
export interface EnemyDef {
  name: string;
  hp: number;
  speed: number;
  radius: number;
  mass: number; // 押し合いの重さ(重いほど押されにくい)
  kbResist: number; // ノックバック耐性(0〜1)
  contactDmg: number; // 接触ダメージ(0なら接触しない)
  contactInterval: number;
  shotDmg: number; // 遠距離攻撃(0なら撃たない)
  shotInterval: number;
  shotRange: number;
  shotSpeed: number;
  armorT: number; // 小ダメージ軽減の閾値T(0なら軽減なし)
  reward: number;
}
export const ENEMY_TYPES: EnemyDef[] = [
  { name: '群れ', hp: 6, speed: 150, radius: 12, mass: 1, kbResist: 0, contactDmg: 1, contactInterval: 1.0,
    shotDmg: 0, shotInterval: 0, shotRange: 0, shotSpeed: 0, armorT: 0, reward: 1 },
  { name: '重装', hp: 40, speed: 80, radius: 18, mass: 3, kbResist: 0.5, contactDmg: 2, contactInterval: 1.5,
    shotDmg: 0, shotInterval: 0, shotRange: 0, shotSpeed: 0, armorT: 8, reward: 8 },
  { name: '遠距離', hp: 10, speed: 100, radius: 12, mass: 1, kbResist: 0, contactDmg: 0, contactInterval: 0,
    shotDmg: 2, shotInterval: 2.5, shotRange: 350, shotSpeed: 300, armorT: 0, reward: 3 },
];
export const SPAWN_MIX = [0.7, 0.15, 0.15]; // 群れ・重装・遠距離の出現割合

export const SPAWN = {
  perTick: 20, // 1ティックに補充する最大数
  attempts: 8, // ランダム抽選の試行回数
  playerExclusion: 400, // プレイヤーからの除外距離
  towerExclusion: 200, // タワーからの除外距離
  markerTime: 1.5, // 出現予告の表示時間(秒)。0なら予告なしで即出現
};

// 敵同士の軽い分離
export const SEPARATION = { stiffness: 0.5, maxPush: 3, knockbackDecay: 0.88 };

/** 武器。範囲は px、間隔は秒、knockback は初速(px/s)。 */
export type WeaponKind = 'melee' | 'arrow' | 'fireball';
export interface WeaponDef {
  id: string;
  name: string;
  kind: WeaponKind;
  damage: number;
  interval: number;
  range: number;
  crit: number; // クリティカル率(0〜1)
  knockback: number;
  projSpeed: number;
  blastRadius: number;
  arcHalfDeg: number;
}
export const WEAPONS: WeaponDef[] = [
  { id: 'sword', name: '剣', kind: 'melee', damage: 8, interval: 1.0, range: 120, crit: 0.05, knockback: 400,
    projSpeed: 0, blastRadius: 0, arcHalfDeg: 75 },
  { id: 'bow', name: '弓', kind: 'arrow', damage: 5, interval: 0.8, range: 500, crit: 0.05, knockback: 150,
    projSpeed: 900, blastRadius: 0, arcHalfDeg: 0 },
  { id: 'wand', name: 'ワンド', kind: 'fireball', damage: 4, interval: 1.2, range: 350, crit: 0, knockback: 0,
    projSpeed: 500, blastRadius: 60, arcHalfDeg: 0 },
];

// タワー(M1の負荷検証用。M3で本実装)
export const TOWER = { damage: 10, interval: 1.5, range: 600, cols: 5, spacing: 120 };
export const BULLET = { speed: 900, radius: 5, fireballRadius: 8, life: 0.9 };
export const ENEMY_BULLET = { radius: 5, life: 3 };
export const COIN = { mergeRadius: 100 };
