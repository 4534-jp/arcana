// ヘッドレス実行のシミュレーション性能計測: npm run bench
// 描画を含まないので、ここで出る値は「ロジック側の処理時間」のみ。
import { World } from './sim/world';
import { TICK } from './sim/config';

interface Scenario {
  label: string;
  enemies: number;
  towerFireMul: number;
  markerTime: number;
  separation: boolean;
}

function run(s: Scenario, seconds = 60) {
  const w = new World({ seed: 12345, towers: 20, godMode: true, autoOrbit: true, weaponId: 'bow' });
  w.setEnemyTarget(s.enemies);
  w.towerFireMul = s.towerFireMul;
  w.markerTime = s.markerTime;
  w.separationOn = s.separation;
  for (let i = 0; i < 600; i++) w.step(TICK); // ウォームアップ(10秒)
  const ticks = Math.round(seconds / TICK);
  const times = new Float64Array(ticks);
  let sumB = 0, sumF = 0, sumC = 0, sumE = 0;
  const k0 = w.kills;
  for (let i = 0; i < ticks; i++) {
    const t0 = performance.now();
    w.step(TICK);
    times[i] = performance.now() - t0;
    sumB += w.bulletCount; sumF += w.ebulletCount; sumC += w.coinCount; sumE += w.enemyCount;
  }
  const sorted = Array.from(times).sort((a, b) => a - b);
  const avg = sorted.reduce((a, b) => a + b, 0) / ticks;
  console.log(
    `${s.label.padEnd(30)} 平均 ${avg.toFixed(3)}ms  p99 ${sorted[Math.floor(ticks * 0.99)].toFixed(3)}ms  最大 ${sorted[ticks - 1].toFixed(3)}ms | ` +
    `敵 ${(sumE / ticks).toFixed(0)}  弾 ${(sumB / ticks).toFixed(0)}  敵弾 ${(sumF / ticks).toFixed(0)}  通貨 ${(sumC / ticks).toFixed(0)}  撃破/秒 ${((w.kills - k0) / seconds).toFixed(1)}`,
  );
}

console.log('1ティック(1/60秒)あたりのシミュレーション処理時間 [60秒分、ウォームアップ除く]');
console.log('※ 16.7ms が60fpsの1フレーム予算。描画時間は含まない。タワー20基・3種の敵・予告マーカーあり。\n');
run({ label: '敵600 ×1 / 分離ON', enemies: 600, towerFireMul: 1, markerTime: 1.5, separation: true });
run({ label: '敵600 ×1 / 分離OFF', enemies: 600, towerFireMul: 1, markerTime: 1.5, separation: false });
run({ label: '敵600 ×32 / 分離ON', enemies: 600, towerFireMul: 32, markerTime: 1.5, separation: true });
run({ label: '敵1000 ×32 / 分離ON', enemies: 1000, towerFireMul: 32, markerTime: 1.5, separation: true });
run({ label: '敵1000 ×32 / 分離OFF', enemies: 1000, towerFireMul: 32, markerTime: 1.5, separation: false });
