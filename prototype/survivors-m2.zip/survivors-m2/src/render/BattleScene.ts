import Phaser from 'phaser';
import { World } from '../sim/world';
import {
  CRIT_MUL, ENEMY_TYPES, MAP_H, MAP_W, MAX_BLAST, MAX_BULLETS, MAX_COINS, MAX_DN, MAX_EBULLETS, MAX_ENEMIES,
  MAX_PENDING, MAX_SLASH, MAX_TOWERS, TICK, WEAPONS,
} from '../sim/config';

type Mode = 'select' | 'play' | 'dead';
const MARKER_TIMES = [1.5, 0.5, 0]; // 出現予告の時間(0は予告なし)。呪い付きアイテムの想定
const ENEMY_COLORS = [0xe05555, 0xd08a3c, 0xc060e0];

interface Settings {
  enemyTarget: number;
  towerOn: boolean;
  towerFireMul: number;
  markerIdx: number;
  separation: boolean;
  damageNumbers: boolean;
  fullMap: boolean;
  renderOn: boolean;
}

/**
 * 戦闘シーン(M1の負荷検証+M2の戦闘の核)。シミュレーション(World)の結果を表示するだけで、ルールは持たない。
 */
export class BattleScene extends Phaser.Scene {
  private world!: World;
  private mode: Mode = 'select';
  private lastWeaponId = 'bow';
  private acc = 0;
  private settings: Settings = {
    enemyTarget: 40, towerOn: false, towerFireMul: 1, markerIdx: 0, separation: true,
    damageNumbers: true, fullMap: false, renderOn: true,
  };

  private markerSprites: Phaser.GameObjects.Image[] = [];
  private coinSprites: Phaser.GameObjects.Image[] = [];
  private towerSprites: Phaser.GameObjects.Image[] = [];
  private enemySprites: Phaser.GameObjects.Image[] = [];
  private ebulletSprites: Phaser.GameObjects.Image[] = [];
  private bulletSprites: Phaser.GameObjects.Image[] = [];
  private blastSprites: Phaser.GameObjects.Image[] = [];
  private slashSprites: Phaser.GameObjects.Image[] = [];
  private dnTexts: Phaser.GameObjects.Text[] = [];
  private playerSprite!: Phaser.GameObjects.Image;
  // スプライトに今設定されているテクスチャの種類(変わったときだけ setTexture する)
  private enemyKind = new Int8Array(MAX_ENEMIES).fill(-1);
  private markerKind = new Int8Array(MAX_PENDING).fill(-1);
  private bulletKind = new Int8Array(MAX_BULLETS).fill(-1);
  private dnSeen = new Uint32Array(MAX_DN);

  private keys!: Record<string, Phaser.Input.Keyboard.Key>;
  private hud!: HTMLElement;
  private msg!: HTMLElement;
  private hudTimer = 0;
  private simSum = 0;
  private simMax = 0;
  private syncSum = 0;
  private frames = 0;

  constructor() {
    super('battle');
  }

  create(): void {
    this.makeTextures();
    this.world = new World({ weaponId: this.lastWeaponId });

    this.add.tileSprite(MAP_W / 2, MAP_H / 2, MAP_W, MAP_H, 'grid');
    // 描画順:予告 → 通貨 → タワー → 敵 → 敵弾 → 弾 → エフェクト → プレイヤー → ダメージ数字
    for (let i = 0; i < MAX_PENDING; i++) this.markerSprites.push(this.add.image(0, 0, 'marker0').setVisible(false));
    for (let i = 0; i < MAX_COINS; i++) this.coinSprites.push(this.add.image(0, 0, 'coin').setVisible(false));
    for (let i = 0; i < MAX_TOWERS; i++) this.towerSprites.push(this.add.image(0, 0, 'tower').setVisible(false));
    for (let i = 0; i < MAX_ENEMIES; i++) this.enemySprites.push(this.add.image(0, 0, 'enemy0').setVisible(false));
    for (let i = 0; i < MAX_EBULLETS; i++) this.ebulletSprites.push(this.add.image(0, 0, 'ebullet').setVisible(false));
    for (let i = 0; i < MAX_BULLETS; i++) this.bulletSprites.push(this.add.image(0, 0, 'bullet').setVisible(false));
    for (let i = 0; i < MAX_BLAST; i++) this.blastSprites.push(this.add.image(0, 0, 'blast').setVisible(false));
    for (let i = 0; i < MAX_SLASH; i++) {
      this.slashSprites.push(this.add.image(0, 0, 'slash').setOrigin(0, 0.5).setVisible(false));
    }
    this.playerSprite = this.add.image(this.world.px, this.world.py, 'player');
    for (let i = 0; i < MAX_DN; i++) {
      this.dnTexts.push(
        this.add
          .text(0, 0, '', { fontFamily: 'monospace', fontSize: '18px', color: '#ffffff', stroke: '#000000', strokeThickness: 3 })
          .setOrigin(0.5)
          .setVisible(false),
      );
    }

    this.hud = document.getElementById('hud') as HTMLElement;
    this.msg = document.getElementById('msg') as HTMLElement;
    this.setupInput();
    this.applyCamera();
    this.scale.on('resize', () => this.applyCamera());
    this.showMessage();
  }

  // ---------------- テクスチャ ----------------
  private makeTextures(): void {
    const g = this.make.graphics({ x: 0, y: 0 }, false);
    const circle = (key: string, color: number, r: number, alpha = 1) => {
      g.clear();
      g.fillStyle(color, alpha);
      g.fillCircle(r, r, r);
      g.generateTexture(key, r * 2, r * 2);
    };
    ENEMY_TYPES.forEach((t, i) => circle('enemy' + i, ENEMY_COLORS[i], t.radius));
    circle('ebullet', 0xe8a0ff, 5);
    circle('bullet', 0xffe066, 5);
    circle('fireball', 0xff8a30, 8);
    circle('coin', 0xf5c542, 6);
    circle('player', 0x55e07a, 14);
    circle('blast', 0xffa040, 60, 0.55);
    ENEMY_COLORS.forEach((c, i) => {
      g.clear();
      g.fillStyle(c, 0.18);
      g.fillCircle(18, 18, 15);
      g.lineStyle(3, c, 1);
      g.strokeCircle(18, 18, 15);
      g.generateTexture('marker' + i, 36, 36);
    });
    g.clear();
    g.fillStyle(0x5599ff, 1);
    g.fillRect(0, 0, 24, 24);
    g.generateTexture('tower', 24, 24);
    // 剣の斬撃:+x方向を中心とした扇形(半径128、±75度)
    g.clear();
    g.fillStyle(0xcfe8ff, 0.75);
    const pts: Phaser.Math.Vector2[] = [new Phaser.Math.Vector2(0, 128)];
    for (let a = -75; a <= 75; a += 5) {
      const r = (a * Math.PI) / 180;
      pts.push(new Phaser.Math.Vector2(Math.cos(r) * 128, 128 + Math.sin(r) * 128));
    }
    g.fillPoints(pts, true);
    g.generateTexture('slash', 128, 256);
    // 背景の格子
    g.clear();
    g.fillStyle(0x14161c, 1);
    g.fillRect(0, 0, 128, 128);
    g.fillStyle(0x222838, 1);
    g.fillRect(0, 0, 128, 2);
    g.fillRect(0, 0, 2, 128);
    g.generateTexture('grid', 128, 128);
    g.destroy();
  }

  // ---------------- 入力 ----------------
  private setupInput(): void {
    const kb = this.input.keyboard;
    if (!kb) return;
    this.keys = kb.addKeys('W,A,S,D,UP,DOWN,LEFT,RIGHT') as Record<string, Phaser.Input.Keyboard.Key>;
    const s = this.settings;
    WEAPONS.forEach((w, i) => {
      kb.on('keydown-' + ['ONE', 'TWO', 'THREE'][i], () => {
        if (this.mode !== 'play') this.startGame(w.id);
      });
    });
    kb.on('keydown-ENTER', () => {
      if (this.mode === 'dead') this.startGame(this.lastWeaponId);
    });
    kb.on('keydown-E', (ev: KeyboardEvent) => this.changeEnemyTarget(ev.shiftKey ? 100 : 20));
    kb.on('keydown-Q', (ev: KeyboardEvent) => this.changeEnemyTarget(ev.shiftKey ? -100 : -20));
    kb.on('keydown-F', () => (this.settings.towerFireMul = Math.min(32, s.towerFireMul * 2), this.applySettings()));
    kb.on('keydown-G', () => (this.settings.towerFireMul = Math.max(0.25, s.towerFireMul / 2), this.applySettings()));
    kb.on('keydown-M', () => (this.settings.markerIdx = (s.markerIdx + 1) % MARKER_TIMES.length, this.applySettings()));
    kb.on('keydown-B', () => (this.settings.separation = !s.separation, this.applySettings()));
    kb.on('keydown-N', () => {
      this.settings.damageNumbers = !s.damageNumbers;
      this.applySettings();
      if (!s.damageNumbers) for (const t of this.dnTexts) t.setVisible(false);
    });
    kb.on('keydown-T', () => {
      this.settings.towerOn = !s.towerOn;
      if (this.mode !== 'select') this.startGame(this.lastWeaponId); // タワー数は開始時に決まるので再開する
    });
    kb.on('keydown-Z', () => (this.settings.fullMap = !s.fullMap, this.applyCamera()));
    kb.on('keydown-R', () => this.toggleRender());
  }

  private changeEnemyTarget(delta: number): void {
    this.settings.enemyTarget = Math.max(0, Math.min(MAX_ENEMIES, this.settings.enemyTarget + delta));
    this.applySettings();
  }

  private applySettings(): void {
    const s = this.settings;
    this.world.setEnemyTarget(s.enemyTarget);
    this.world.towerFireMul = s.towerFireMul;
    this.world.markerTime = MARKER_TIMES[s.markerIdx];
    this.world.separationOn = s.separation;
    this.world.damageNumbersOn = s.damageNumbers;
  }

  private toggleRender(): void {
    this.settings.renderOn = !this.settings.renderOn;
    if (!this.settings.renderOn) {
      for (const pool of [this.markerSprites, this.coinSprites, this.enemySprites, this.ebulletSprites, this.bulletSprites,
        this.blastSprites, this.slashSprites, this.dnTexts]) {
        for (const o of pool) o.setVisible(false);
      }
    }
  }

  // ---------------- ゲームの開始・終了 ----------------
  private startGame(weaponId: string): void {
    this.lastWeaponId = weaponId;
    this.world = new World({
      seed: (Math.random() * 1e9) | 0,
      weaponId,
      towers: this.settings.towerOn ? MAX_TOWERS : 0,
    });
    this.applySettings();
    this.acc = 0;
    this.mode = 'play';
    this.dnSeen.fill(0);
    for (let i = 0; i < MAX_TOWERS; i++) {
      this.towerSprites[i]
        .setPosition(this.world.tx[i], this.world.ty[i])
        .setVisible(i < this.world.towerCount);
    }
    this.cameras.main.centerOn(this.world.px, this.world.py);
    this.showMessage();
  }

  private showMessage(): void {
    if (this.mode === 'play') {
      this.msg.style.display = 'none';
      return;
    }
    const list = WEAPONS.map((w, i) => `[${i + 1}] ${w.name}`).join('   ');
    const w = this.world;
    this.msg.style.display = 'block';
    this.msg.textContent =
      this.mode === 'select'
        ? `武器を選んでください\n\n${list}\n\n移動: WASD / 矢印キー(攻撃は自動)`
        : `死亡\n生存 ${w.time.toFixed(1)}秒 / 撃破 ${w.kills} / 所持通貨 ${Math.round(w.gold)}\n\n${list}   で武器を選んで再開\n[Enter] 同じ武器で再開`;
  }

  private applyCamera(): void {
    const cam = this.cameras.main;
    cam.setBounds(0, 0, MAP_W, MAP_H);
    if (this.settings.fullMap) {
      cam.stopFollow();
      cam.setZoom(Math.min(this.scale.width / MAP_W, this.scale.height / MAP_H));
      cam.centerOn(MAP_W / 2, MAP_H / 2);
    } else {
      cam.setZoom(this.scale.height / 1080); // 縦1080pxぶんが見える大きさ
      cam.startFollow(this.playerSprite, true, 0.12, 0.12);
    }
  }

  // ---------------- 毎フレーム ----------------
  update(_time: number, delta: number): void {
    const t0 = performance.now();
    if (this.mode === 'play') {
      const k = this.keys;
      const ix = (k.D.isDown || k.RIGHT.isDown ? 1 : 0) - (k.A.isDown || k.LEFT.isDown ? 1 : 0);
      const iy = (k.S.isDown || k.DOWN.isDown ? 1 : 0) - (k.W.isDown || k.UP.isDown ? 1 : 0);
      // 固定タイムステップ:描画が重くてもロジックの進み方は変わらない
      this.acc += Math.min(delta, 100) / 1000;
      let steps = 0;
      while (this.acc >= TICK && steps < 4) {
        this.world.step(TICK, ix, iy);
        this.acc -= TICK;
        steps++;
      }
      if (steps === 4) this.acc = 0; // 追いつけない場合は遅れを捨てる
      if (this.world.dead) {
        this.mode = 'dead';
        this.showMessage();
      }
    }
    const t1 = performance.now();
    if (this.settings.renderOn) this.syncSprites();
    const t2 = performance.now();

    this.simSum += t1 - t0;
    this.simMax = Math.max(this.simMax, t1 - t0);
    this.syncSum += t2 - t1;
    this.frames++;
    this.hudTimer += delta;
    if (this.hudTimer >= 250) this.updateHud();
  }

  private syncSprites(): void {
    const w = this.world;
    for (let i = 0; i < MAX_PENDING; i++) {
      const s = this.markerSprites[i];
      if (w.malive[i]) {
        const p = 1 - w.mt[i] / w.mtot[i]; // 0→1
        if (this.markerKind[i] !== w.mtype[i]) {
          s.setTexture('marker' + w.mtype[i]);
          this.markerKind[i] = w.mtype[i];
        }
        s.setPosition(w.mx[i], w.my[i]).setAlpha(0.3 + 0.7 * p).setScale(1.5 - 0.5 * p);
        if (!s.visible) s.setVisible(true);
      } else if (s.visible) {
        s.setVisible(false);
      }
    }
    for (let i = 0; i < MAX_COINS; i++) {
      const s = this.coinSprites[i];
      if (w.calive[i]) {
        s.setPosition(w.cx[i], w.cy[i]);
        if (!s.visible) s.setVisible(true);
      } else if (s.visible) {
        s.setVisible(false);
      }
    }
    for (let i = 0; i < MAX_ENEMIES; i++) {
      const s = this.enemySprites[i];
      if (w.ealive[i]) {
        if (this.enemyKind[i] !== w.etype[i]) {
          s.setTexture('enemy' + w.etype[i]);
          this.enemyKind[i] = w.etype[i];
        }
        s.setPosition(w.ex[i], w.ey[i]);
        if (!s.visible) s.setVisible(true);
      } else if (s.visible) {
        s.setVisible(false);
      }
    }
    for (let i = 0; i < MAX_EBULLETS; i++) {
      const s = this.ebulletSprites[i];
      if (w.falive[i]) {
        s.setPosition(w.fx[i], w.fy[i]);
        if (!s.visible) s.setVisible(true);
      } else if (s.visible) {
        s.setVisible(false);
      }
    }
    for (let i = 0; i < MAX_BULLETS; i++) {
      const s = this.bulletSprites[i];
      if (w.balive[i]) {
        if (this.bulletKind[i] !== w.bkind[i]) {
          s.setTexture(w.bkind[i] === 1 ? 'fireball' : 'bullet');
          this.bulletKind[i] = w.bkind[i];
        }
        s.setPosition(w.bx[i], w.by[i]);
        if (!s.visible) s.setVisible(true);
      } else if (s.visible) {
        s.setVisible(false);
      }
    }
    for (let i = 0; i < MAX_BLAST; i++) {
      const s = this.blastSprites[i];
      if (w.blLife[i] > 0) {
        const p = 1 - w.blLife[i] / 0.2;
        s.setPosition(w.blX[i], w.blY[i]).setScale((w.blR[i] / 60) * (0.7 + 0.4 * p)).setAlpha(1 - p);
        if (!s.visible) s.setVisible(true);
      } else if (s.visible) {
        s.setVisible(false);
      }
    }
    for (let i = 0; i < MAX_SLASH; i++) {
      const s = this.slashSprites[i];
      if (w.slLife[i] > 0) {
        s.setPosition(w.slX[i], w.slY[i]).setRotation(w.slAng[i]).setScale(w.slR[i] / 128).setAlpha(w.slLife[i] / 0.15);
        if (!s.visible) s.setVisible(true);
      } else if (s.visible) {
        s.setVisible(false);
      }
    }
    this.playerSprite.setPosition(w.px, w.py).setAlpha(w.hurtFlash > 0 ? 0.4 : 1);
    if (this.settings.damageNumbers) {
      for (let i = 0; i < MAX_DN; i++) {
        const t = this.dnTexts[i];
        if (w.dnlife[i] > 0) {
          if (this.dnSeen[i] !== w.dnid[i]) {
            const v = w.dnv[i];
            const crit = w.dncrit[i] === 1;
            t.setText(v < 10 ? v.toFixed(1) : Math.round(v).toString());
            t.setColor(crit ? '#ffe066' : '#ffffff');
            t.setFontSize(crit ? 26 : 18);
            this.dnSeen[i] = w.dnid[i];
          }
          t.setPosition(w.dnx[i], w.dny[i]).setAlpha(Math.min(1, w.dnlife[i] / 0.3));
          if (!t.visible) t.setVisible(true);
        } else if (t.visible) {
          t.setVisible(false);
        }
      }
    }
  }

  private updateHud(): void {
    const w = this.world;
    const s = this.settings;
    const f = Math.max(1, this.frames);
    const wp = w.weapon;
    const iv = (v: number) => `${Math.round(v * 100)}%`;
    const hpBar = '█'.repeat(Math.ceil(w.hp)) + '░'.repeat(Math.max(0, w.maxHp - Math.ceil(w.hp)));
    const tc = w.typeCount;
    this.hud.textContent =
      `FPS ${this.game.loop.actualFps.toFixed(1)}   ロジック ${(this.simSum / f).toFixed(2)}ms (最大 ${this.simMax.toFixed(2)})  同期 ${(this.syncSum / f).toFixed(2)}ms  描画 ${s.renderOn ? 'ON' : 'OFF'}\n` +
      `HP ${w.hp.toFixed(1)}/${w.maxHp}  ${hpBar}\n` +
      `武器 ${wp.def.name}: ダメージ ${wp.damage.toFixed(1)}(${iv(wp.iv.damage)})  間隔 ${wp.interval.toFixed(2)}s(${iv(wp.iv.speed)})  ` +
      `範囲 ${Math.round(wp.range)}px(${iv(wp.iv.range)})  クリ ${(wp.crit * 100).toFixed(1)}%×${CRIT_MUL}(${iv(wp.iv.crit)})  KB ${Math.round(wp.knockback)}(${iv(wp.iv.knockback)})\n` +
      `敵 ${w.enemyCount}/${w.enemyTarget} (${ENEMY_TYPES.map((t, i) => `${t.name}${tc[i]}`).join(' ')})  予告 ${w.pendingCount}  ` +
      `弾 ${w.bulletCount}/${MAX_BULLETS}  敵弾 ${w.ebulletCount}/${MAX_EBULLETS}  通貨 ${w.coinCount}/${MAX_COINS}\n` +
      `時間 ${w.time.toFixed(1)}s  撃破 ${w.kills}  所持通貨 ${Math.round(w.gold)}  被ダメージ ${w.damageTaken.toFixed(1)}\n` +
      `設定: 敵数 ${s.enemyTarget} / 予告 ${MARKER_TIMES[s.markerIdx] > 0 ? MARKER_TIMES[s.markerIdx] + 's' : 'なし'} / 分離 ${s.separation ? 'ON' : 'OFF'} / ` +
      `ダメージ数字 ${s.damageNumbers ? 'ON' : 'OFF'} / タワー ${s.towerOn ? '20基(発射×' + s.towerFireMul + ')' : 'なし'} / カメラ ${s.fullMap ? '全体' : '追従'}\n` +
      `[WASD/矢印]移動 [E/Q]敵数±20(Shiftで±100) [M]予告時間 [B]分離 [N]数字 [T]タワー [F/G]タワー発射速度 [Z]カメラ [R]描画`;
    this.simSum = 0;
    this.simMax = 0;
    this.syncSum = 0;
    this.frames = 0;
    this.hudTimer = 0;
  }
}
