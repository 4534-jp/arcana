// ロジックの動作確認(ヘッドレス): npm run check
import { World } from './sim/world';
import { TICK, ENEMY_TYPES } from './sim/config';

let ng = 0;
function ok(name: string, cond: boolean, detail = '') {
  if (!cond) ng++;
  console.log(`${cond ? 'OK' : 'NG'}  ${name}${detail ? '  ' + detail : ''}`);
}

// 1. 小ダメージ軽減:重装(HP40, T=8)1体を倒すまでの時間(個体値は全て75%に固定、クリティカルは乱数)
console.log('--- 重装1体を倒す時間(個体値75%固定・動かない的・200回の平均) ---');
const ranges: Record<string, number> = { sword: 60, bow: 200, wand: 150 };
for (const id of ['sword', 'bow', 'wand']) {
  const times: number[] = [];
  for (let s = 1; s <= 200; s++) {
    const w = new World({ seed: s, weaponId: id, ivFixed: 0.75, godMode: true, freezeEnemies: true });
    w.setEnemyTarget(0);
    w.debugSpawn(1, w.px + ranges[id], w.py);
    while (w.enemyCount > 0 && w.time < 300) w.step(TICK);
    times.push(w.time);
  }
  times.sort((a, b) => a - b);
  const mean = times.reduce((a, b) => a + b, 0) / times.length;
  console.log(`${id.padEnd(6)} 平均 ${mean.toFixed(1)}秒  中央値 ${times[100].toFixed(1)}秒  (最短 ${times[0].toFixed(1)} / 最長 ${times[199].toFixed(1)})`);
}

// 2. 出現予告:1.5秒たつまで敵は出ず、予告だけが出る
{
  const w = new World({ seed: 1, godMode: true });
  w.markerTime = 1.5;
  w.setEnemyTarget(20);
  for (let i = 0; i < 80; i++) w.step(TICK); // 約1.33秒
  const early = [w.enemyCount, w.pendingCount];
  for (let i = 0; i < 30; i++) w.step(TICK); // 約1.83秒
  ok('出現予告:1.5秒前は敵0・予告20', early[0] === 0 && early[1] === 20, `(${early.join(',')})`);
  ok('出現予告:1.5秒後に敵20体が出現', w.enemyCount === 20 && w.pendingCount === 0, `(${w.enemyCount},${w.pendingCount})`);
}

// 3. 出現位置:プレイヤーから400px以上離れている(予告なしで多数出して確認)
{
  const w = new World({ seed: 2, godMode: true });
  w.markerTime = 0;
  w.setEnemyTarget(300);
  w.step(TICK);
  let min = Infinity;
  for (let i = 0; i < 1000; i++) {
    if (!w.ealive[i]) continue;
    min = Math.min(min, Math.hypot(w.ex[i] - w.px, w.ey[i] - w.py));
  }
  ok('出現位置:プレイヤーから400px以上', min >= 399.9, `(最小 ${min.toFixed(0)}px)`);
}

// 4. 分離:同じ場所に60体を置くと、分離ONでは重なりが解消される
function overlapRatio(sep: boolean): number {
  const w = new World({ seed: 3, godMode: true, freezeEnemies: false });
  w.separationOn = sep;
  w.markerTime = 0;
  w.setEnemyTarget(0);
  w.px = 3000; w.py = 1800; // 敵から遠ざけて、移動の影響を小さくする
  for (let i = 0; i < 60; i++) w.debugSpawn(0, 800 + (i % 8) * 3, 800 + Math.floor(i / 8) * 3);
  for (let i = 0; i < 60; i++) w.step(TICK); // 1秒
  let pairs = 0, over = 0;
  for (let i = 0; i < 1000; i++) {
    if (!w.ealive[i]) continue;
    for (let j = i + 1; j < 1000; j++) {
      if (!w.ealive[j]) continue;
      pairs++;
      if (Math.hypot(w.ex[i] - w.ex[j], w.ey[i] - w.ey[j]) < 24 * 0.8) over++;
    }
  }
  return over / pairs;
}
{
  const on = overlapRatio(true);
  const off = overlapRatio(false);
  ok('分離:ONの方が重なりが少ない', on < off * 0.5, `(重なりのある組の割合 ON ${(on * 100).toFixed(1)}% / OFF ${(off * 100).toFixed(1)}%)`);
}

// 5. 遠距離の敵:射程内に入ると撃ち、プレイヤーにダメージが入る
{
  const w = new World({ seed: 4, weaponId: 'sword' });
  w.markerTime = 0;
  w.setEnemyTarget(0);
  w.debugSpawn(2, w.px + 300, w.py);
  for (let i = 0; i < 60 * 4; i++) w.step(TICK);
  ok('遠距離:4秒でプレイヤーが被弾', w.hp < w.maxHp, `(HP ${w.hp.toFixed(1)}/${w.maxHp})`);
}

// 6. 接触ダメージと死亡:HP10のプレイヤーは、囲まれると死ぬ
{
  const w = new World({ seed: 5, weaponId: 'sword' });
  w.markerTime = 0;
  w.setEnemyTarget(0);
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2;
    w.debugSpawn(1, w.px + Math.cos(a) * 40, w.py + Math.sin(a) * 40); // 重装12体
  }
  for (let i = 0; i < 60 * 20 && !w.dead; i++) w.step(TICK);
  ok('死亡:重装に囲まれると死ぬ', w.dead && w.hp === 0, `(死亡 ${w.time.toFixed(1)}秒)`);
}

// 7. 武器の個体値:50〜100%の範囲に収まる
{
  let lo = 1, hi = 0;
  for (let s = 1; s <= 500; s++) {
    const w = new World({ seed: s, weaponId: 'sword' });
    for (const v of Object.values(w.weapon.iv)) { lo = Math.min(lo, v); hi = Math.max(hi, v); }
  }
  ok('個体値:0.5〜1.0の範囲', lo >= 0.5 && hi <= 1.0, `(最小 ${lo.toFixed(3)} / 最大 ${hi.toFixed(3)})`);
}

// 8. 敵の定義が3種そろっている
ok('敵の種類:3種', ENEMY_TYPES.length === 3);

console.log(ng === 0 ? '\nすべてOK' : `\nNG が ${ng} 件`);
if (ng > 0) throw new Error(`${ng} 件のチェックが失敗しました`);
