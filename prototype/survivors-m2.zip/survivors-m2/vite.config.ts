import { defineConfig } from 'vite';

// base を './' にすると、ビルド結果(dist)をどのフォルダ構成からでも開ける(VS Code の Live Server など)
export default defineConfig({ base: './' });
